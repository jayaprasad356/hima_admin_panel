<?php

namespace Rize\UriTemplate\Node;

class Literal extends Abstraction {}
